from django.shortcuts import render
from .models import User
from .forms import UserForm

# Create your views here.

def register_user:
  pass


def login_user:
  pass
